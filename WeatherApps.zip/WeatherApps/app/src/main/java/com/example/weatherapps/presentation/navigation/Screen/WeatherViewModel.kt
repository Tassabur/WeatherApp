package com.example.weatherapps.presentation.navigation.Screen

import android.util.Log
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.weatherapps.data.model.WeatherResponse
import com.example.weatherapps.domain.model.repository.WeatherRepository
import kotlinx.coroutines.launch

class WeatherViewModel : ViewModel() {

    private val repository = WeatherRepository()

    var weatherState by mutableStateOf<WeatherResponse?>(null)
        private set

    var isLoading by mutableStateOf(true)

    init {
        fetchWeather(52.52, 13.41) // Berlin
    }

    private fun fetchWeather(lat: Double, lon: Double) {
        viewModelScope.launch {
            try {
                isLoading = true
                weatherState = repository.getWeather(lat, lon)
            } catch (e: Exception) {
                Log.e("WeatherViewModel", "Error: ${e.message}")
            } finally {
                isLoading = false
            }
        }
    }
}
