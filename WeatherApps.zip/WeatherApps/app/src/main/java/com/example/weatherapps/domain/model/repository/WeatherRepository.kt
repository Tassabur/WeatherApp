package com.example.weatherapps.domain.model.repository

import com.example.weatherapps.data.model.WeatherResponse
import com.example.weatherapps.data.model.remote.RetrofitInstance

class WeatherRepository {
    suspend fun getWeather(latitude: Double, longitude: Double): WeatherResponse {
        return RetrofitInstance.api.getWeather(latitude, longitude)
    }
}
