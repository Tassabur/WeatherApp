package com.example.weatherapps.data.model

import com.google.gson.annotations.SerializedName

data class WeatherResponse(
    val hourly: HourlyData
)

data class HourlyData(
    val time: List<String>,
    @SerializedName("temperature_2m")
    val temperature: List<Double>
)

