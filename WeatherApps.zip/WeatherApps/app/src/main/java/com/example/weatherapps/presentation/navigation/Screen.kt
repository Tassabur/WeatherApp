package com.example.weatherapp.presentation.navigation

sealed class Screen(val route: String) {
    object Weather : Screen("weather_screen")
}
